"use strict";
// will load after loading the page
function firstFunction(){
    var x = 15; 
    console.log("firstFunction x =",x);
}
function secondFunction(){
    console.log("secondFunction (before declaration): x= ",x);
    var x =20;
    console.log("secondFunction (after declaration): x =",x);
}
//////////////////////////////////////
function isEven(){
   var x = document.getElementById("num").value;
     try{
            if(( x % 2)==0){
                console.log("The entered number is even");
            } else{
                throw "Not an Even Number but an Odd Number";
            }  
        }
     catch(msg){
        console.log("Something went wrong!" + msg); }
     finally{
         console.log("I got excecuted regardless of the try catch result"); }
 }

 let studentGrades = ["A","B",3,"D",2];
 let a = studentGrades.length; 
function printArray(){
    for (let i=0;i<a;i++){
        console.log(studentGrades[i]);
    }
}
function printSum(){
    let arrayValues = [1,2,3,4,5];
    var sum =0;
    for (let i=0;i<arrayValues.length;i++){
        sum = sum + arrayValues[i];
    }
    console.log(sum);
}
let score = [43,64,81,91,39,73];
function flagGoodScore(){
    if (score >70) {
        console.log('The score of ${score} is good!');
    }
}



   
   