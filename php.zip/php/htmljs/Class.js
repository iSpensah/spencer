class Vehicle {

    constructor(newMake,newModel,newPrice,newEngine){
        this.make = newMake;
        this.model = newModel;
        this.price = newPrice;
        this.engine = newEngine;
    }
    details = function(){
        console.log('Make: ${this.make} Model: {$this.model} Price: ${this.price}');
    };
};

myCar = new Vehicle("Volvo","v18","20,000","v18Engline");
myCar.details;