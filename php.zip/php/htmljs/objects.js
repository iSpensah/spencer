class Vehicle {
    constructor(newMake,newModel,newPrice,newEngine){
        this.make = newMake;
        this.model = newModel;
        this.price = newPrice;
        this.engine = newEngine;
    }
    details = function(){
        console.log('Make:'+this.make+' Model:'+this.model+' Price:'+this.price+' Engine:' +this.engine);
    };
};
myCar = new Vehicle("Volvo","560",42000, "s60Engine");
function carDetails(){
    //prints the car details
    console.log("My Vechicle details : \n");
    myCar.details();
} 

let fourthItem = {id:4,
    name: "bike",
    price:500,
    brand:"tomy",
    discountedPrice: function() {console.log(this.price*0.10)}};
    console.log("the discounted price of bike is:", fourthItem.discountedPrice );
    console.log(fourthItem.name,fourthItem.brand,fourthItem.price);