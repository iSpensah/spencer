<html>
<head> 
	<title>Welcome to Registration Page </title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</head>
<body>
<br><br>

<center> <b><font size = "6" color ="blue">Welcome to Registration Page</font></b></center>
<hr size ="2"color = "orange"/>

<div>
	<form action = "registered.php" method="post">
	<table width ="30%" height ="30%" align = "center"border ="1" cellspacing = "10" >
		<tr>
			<td colspan="2" align="center"> User Login</td>
		</tr>
		<tr>
			<td>Employee Id</td>
			<td><input type='text' name = 'empid' placeholder = 'Enter ID'>	</td>
		
		</tr>
        <tr>
			<td>Employee Name</td>
			<td><input type='text' name ="ename" placeholder = 'Enter Name' required>	</td>
		</tr>
        <tr>
			<td>Employee city</td>
			<td><select name="ecity">
                <option name = "ecity">N-York</option>
                <option name = "ecity">Phoenix</option>
                <option name = "ecity">Nashville</option>
                <option name = "ecity">Manila</option>
            </select></td>		
		</tr>
        <tr>
			<td>Employee phone</td>
			<td><input type='number' name = 'ephone'  maxlength="11"  placeholder = 'Enter Phone' maxlength="10" required autocomplete=""></td>
		</tr>
		<tr>
			<td>Employee Graduation Status</td> 
			<td>
			<input type='radio'  placeholder = '' name = "x" required>Yes
			<input type='radio'  placeholder = '' name = "x" required>No		
			</td>	
		</tr>
		<tr>
			<td>Password</td> 
			<td><input type='password' name = 'epassword' placeholder = 'Enter Password' required></td>	
		</tr>
		<tr>
			<td>BirthDate</td> 
			<td><input type='date' name = 'edate' placeholder = '' required></td>	
		</tr>
		<tr>
			<td>File</td> 
			<td><input type='file' name = 'efile' placeholder = '' ></td>	
		</tr>
		
		<tr>
			<td colspan = "2" align="right"><input type='submit' name = 'submit' placeholder = 'Enter Password'></td>
		 </tr>	
		
	</table>
</form>
</div>


</body>
</html>





