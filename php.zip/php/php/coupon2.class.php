<?php
$cn = $_POST['name'];
$ce = $_POST['event'];
$cd = $_POST['discountPercent'];

include 'connect.php';
include_once 'coupon.class.php';

$con = mysqli_connect("localhost", "root", "", "user");
$query = "insert into coupon values('$cn','$ce','$cd')";
	$result = mysqli_query($con, $query);

    $c1 = new Coupon($cn,$ce,$cd);
    echo $c1->name. $c1->event.$c1->discountPercent;
 
  